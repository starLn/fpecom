<?php

class TestCase extends CIPHPUnitTestCase
{
}
