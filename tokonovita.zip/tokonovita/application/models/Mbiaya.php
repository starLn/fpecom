<?php 

class Mbiaya extends CI_Model{

    public function get_all_data($tabel){
        $q=$this->db->get($tabel);
        return $q;
    }

    public function insert($tabel, $data){
        $this->db->insert($tabel, $data);
    }

    public function get_by_id($tabel, $id){
        return $this->db->get_where($tabel, $id);
    }

    public function update($tabel, $data, $pk, $id){
        $this->db->where($pk, $id);
        $this->db->update($tabel, $data);
    }

    public function join_table($tabel1, $tabel2, $id){
        $this->db->select('*');
        $this->db->from($tabel1);
        $this->db->join($tabel2, $tabel1.'.'.$id.'='.$tabel2.'.'.$id);
        $query = $this->db->get();
        return $query;
    }
    
    public function joinOngkir() {
        $this->db->select('ongkir.idBiayaKirim, tbl_kurir.namaKurir, kotaAsal.namaKota as namaKotaAsal, kotaTujuan.namaKota as namaKotaTujuan, ongkir.biaya');
        $this->db->from('tbl_biaya_kirim as ongkir');
        $this->db->join('tbl_kurir','tbl_kurir.idKurir = ongkir.idKurir');
        $this->db->join('tbl_kota as kotaAsal','kotaAsal.idKota = ongkir.idKotaAsal');
        $this->db->join('tbl_kota as kotaTujuan','kotaTujuan.idKota = ongkir.idKotaTujuan');
        $query = $this->db->get();
        return $query;
    }
    
}
?>