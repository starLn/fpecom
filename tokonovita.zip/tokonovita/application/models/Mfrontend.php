<?php
class Mfrontend extends CI_Model{
    public function get_all_kategori(){
        return $this->db->get('tbl_kategori');
    }

    public function get_all_kota(){
        return $this->db->get('tbl_kota');
    }

    public function get_all_produk_terbaru(){
        $this->db->order_by('idProduk', 'DESC');
        $this->db->limit(4);
        return $this->db->get('tbl_produk');
    }
    public function update($tabel, $data, $pk, $id){
        $this->db->where($pk, $id);
        $this->db->update($tabel, $data);
    }

    public function insert_reg($data){
        $this->db->insert('tbl_member', $data);
    }
    public function get_toko_by_member(){
        $id = $this->session->userdata('id');
        $q = $this->db->get_where('tbl_toko', array('idKonsumen' => $id));
        return $q;
        
    }
    
}
?>