<?php
class Home extends CI_Controller{
    function __construct()
    {
        parent::__construct();
        $this->load->model('Mfrontend');
        
    }
    public function index(){
        $data['kategori']=$this->Mfrontend->get_all_kategori()->result();
        $data['produk_terbaru']=$this->Mfrontend->get_all_produk_terbaru()->result();
        $this->template->load('layout_frontend','frontend/home', $data);
    }
   
    public function register(){
        $data['kota']=$this->Mfrontend->get_all_kota()->result();
        $data['kategori']=$this->Mfrontend->get_all_kategori()->result();
        $this->template->load('layout_frontend','frontend/register', $data);
    
    }

    public function login(){
        $data['kategori']=$this->Mfrontend->get_all_kategori()->result();
        $this->template->load('layout_frontend','frontend/login',$data);
    }
    public function logout(){
        $this->session->sess_destroy();
            redirect('home/login');
        
    }
    public function member(){
        $data['toko']= $this->Mfrontend->get_toko_by_member()->result_array();
        $data['kategori']=$this->Mfrontend->get_all_kategori()->result();
        $this->template->load('layout_utama','frontend/dashboard',$data);
    }


    public function daftar()
    {
        $this->load->library('form_validation');
        
        $this->form_validation->set_rules('namaKonsumen', 'namaKonsumen', 'required|trim', true);
        $this->form_validation->set_rules('email', 'email', 'required|trim|valid_email');
        $this->form_validation->set_rules('username', 'username', 'required|trim');
        $this->form_validation->set_rules('password', 'password', 'required|trim|min_length[6]|matches[password2]');
        $this->form_validation->set_rules('password2', 'password', 'required|trim|matches[password]');
        $this->form_validation->set_rules('alamat', 'alamat', 'required|trim', true);
        $this->form_validation->set_rules('idKota', 'idKota', 'required|trim', true);
        $this->form_validation->set_rules('tlpn', 'tlpn', 'required|trim', true);

        if ($this->form_validation->run() == false) {
            $this->template->load('layout_frontend','frontend/register');
        } else {
            $namaKonsumen = $this->input->post('namaKonsumen');
            $email = $this->input->post('email');
            $username = $this->input->post('username');
            $password = $this->input->post('password');
            $alamat = $this->input->post('alamat');
            $idKota = $this->input->post('idKota');
            $tlpn = $this->input->post('tlpn');
            $data_insert = array(
                'namaKonsumen' => $namaKonsumen,
                'email' => $email,
                'username' => $username,
                'password' => $password,
                'alamat' => $alamat,
                'idKota' => $idKota,
                'tlpn' => $tlpn,
                'statusAktif' => 'Y'
       );

            $this->Mfrontend->insert_reg($data_insert);

            redirect('home/login');
        }
    }

    public function masuk(){
        $this->load->model('Mlogin');
        $u= $this->input->post('username');
        $p= $this->input->post('password');
    
        $cek = $this->Mlogin->cek_masuk($u,$p)->num_rows();
        $result = $this->Mlogin->cek_masuk($u,$p)->result();
        
        if($cek==1){
            $data_session = array(
                'userName' => $u,
                'id' => $result->idKonsumen,
                'status' => 'login'
            );
        $this->session->set_userdata($data_session);
        redirect('home/member');
        }else{
            $this->session->set_flashdata('pesan', 'Username/Password Invalid');
            redirect('home/login');
        }  
    
    }
    public function toko(){
        $data['kategori']= $this->Mfrontend->get_all_kategori()->result();
        $data['toko']= $this->Mfrontend->get_toko_by_member()->result_array();
        $this->template->load('layout_utama', 'frontend/toko',$data);
    }
    public function gantistatustidakaktif($id){
        $dataUpdate = array('statusAktif' => 'N');
        $this->Mfrontend->update('tbl_toko', $dataUpdate, 'idKonsumen', $id);
        redirect('toko');
    }
    public function gantistatusaktif($id){
        $dataUpdate = array('statusAktif' => 'Y');
        $this->Mfrontend->update('tbl_toko', $dataUpdate, 'idKonsumen', $id);
        redirect('home/toko');
    }
    public function tambahtoko(){
        $data['kategori']= $this->Mfrontend->get_all_kategori()->result();
        $data['toko']= $this->Mfrontend->get_toko_by_member()->result_array();
        $this->template->load('layout_utama', 'frontend/form_tambah_toko',$data);
    }

    public function tambah_action_toko(){
        // $data['kategori']= $this->Mfrontend->get_all_kategori()->result();
        // $data['toko']= $this->Mfrontend->get_toko_by_member()->result_array();
        // $id = $this->session->user_data('id');
        $namaToko = $this->input->post('namaToko');
        $config['upload_path'] = './uploads/';
        $config['allowed_types'] = 'jpg|png|PNG|jpeg';
        $config['max_size'] = 10000;
        $config['max_width'] = 10000;
        $config['max_height'] = 10000;

        $this->load->library('upload', $config);

        if(!$this->upload->do_upload('logo')){
            redirect('home/tambahtoko');
            // echo("Gagal Upload!");
        }else {
            $data = array('upload_data' => $this->upload->data());
            echo("Berhasil Upload!");
            $this->load->view('toko');
        }
        $logo = $this->upload->data('file_name');
        $deskripsi = $this->input->post('deskripsi');
        $data = $this->db->get_where('tbl_member')->row_array();
        $data = array(
            'idKonsumen' => $data['idKonsumen'],
            'namaToko' => $namaToko,
            'logo' => $logo,
            'deskripsi' => $deskripsi,
            'statusAktif' => 'Y'
        );
        $this->db->insert('tbl_toko', $data);
        redirect('toko');
    }


    
    // public function masuk()
    // {
    //     $username = $this->input->post('username');
    //     $password = $this->input->post('password');

    //     $user = $this->db->get_where('tbl_member', ['username' => $username])->row_array();

    //     if ($user) {
    //         if (password_verify($password, $user['password'])) {
    //             $data = [
    //                 'username' => $username,
    //                 'password' => $password
    //             ];
    //             $this->session->set_userdata($data);
    //             redirect('home/member');
    //         } else {
    //             $this->session->set_flashdata('flash', 'Login failed');
    //             redirect('home/login');
                
    //         }
    //     } else {
    //         $this->session->set_flashdata('flash', 'Login failed');
    //         redirect('home/login');
    //     }
    // }
    // public function act_reg()
    // {
    //     $this->load->library('form_validation');
        
    //     $this->form_validation->set_rules('namaKonsumen', 'namaKonsumen', 'required|trim', true);
    //     $this->form_validation->set_rules('email', 'email', 'required|trim|valid_email');
    //     $this->form_validation->set_rules('username', 'username', 'required|trim');
    //     $this->form_validation->set_rules('password1', 'password', 'required|trim|matches[password2]');
    //     $this->form_validation->set_rules('password2', 'password', 'required|trim|matches[password1]');
    //     $this->form_validation->set_rules('alamat', 'alamat', 'required|trim', true);
    //     $this->form_validation->set_rules('kota', 'kota', 'required|trim', true);
    //     $this->form_validation->set_rules('tlpn', 'tlpn', 'required|trim', true);
        
    //     if ($this->form_validation->run() == false) {
    //         // $this->template->load('layout_frontend','frontend/register');
    //         echo ("Register Failed!");
    //     } else {
    //         $nama = $this->input->post('nama');
    //         $email = $this->input->post('email');
    //         $username = $this->input->post('username');
    //         $password = $this->input->post('password');
    //         $alamat = $this->input->post('alamat');
    //         $idKota = $this->input->post('idKota');
    //         $tlpn = $this->input->post('tlpn');
    //         $data_insert = array(
    //             'username' => $username,
    //             'password' => $password,
    //             'namaKonsumen' => $nama,
    //             'alamat' => $alamat,
    //             'idKota' => $idKota,
    //             'email' => $email,
    //             'tlpn' => $tlpn,
    //             'statusAktif' => 'Y'
    //    );

    //         $this->Mfrontend->insert_reg($data_insert);

    //         redirect('home');
    //     }
    // }
    // public function save(){
    //     $username = $this->input->post('username');
    //     $password1 = $this->input->post('password');
    //     $password2 = $this->input->post('password');
    //     $namaKonsumen = $this->input->post('namaKonsumen');
    //     $alamat = $this->input->post('alamat');
    //     $kota = $this->input->post('idKota');
    //     $email = $this->input->post('email');
    //     $tlpn = $this->input->post('tlpn');
    //     // $statusAktif = $this->input->post('statusAktif');
    //     $dataInsert = array(
    //         'username'=>$username,
    //         'password'=>$password1,
    //         'password'=>$password2,
    //         'namaKonsumen'=>$namaKonsumen,
    //         'alamat'=>$alamat,
    //         'idKota'=>$kota,
    //         'email'=>$email,
    //         'tlpn'=>$tlpn,
    //         'statusAktif'=>'Y'
    //     );
    //     $this->Mfrontend->insert_reg($dataInsert);
    //     redirect('member');
    // }
   
}
?>