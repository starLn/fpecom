<?php 
class Ongkoskirim extends CI_Controller{

    function __construct(){
        parent::__construct();
        $this->load->model('Mbiaya');
    }

    public function index(){
        $data['ongkir']=$this->Mbiaya->get_all_data('tbl_biaya_kirim')->result();
        $data['kota']=$this->Mbiaya->get_all_data('tbl_kota')->result();
        $data['join']=$this->Mbiaya->joinOngkir()->result();
        $this->template->load('layout_admin','admin/ongkoskirim/index', $data);
    }

    public function add(){
        $data['kurir']=$this->Mbiaya->get_all_data('tbl_kurir')->result();
        $data['kota']=$this->Mbiaya->get_all_data('tbl_kota')->result();
        $this->template->load('layout_admin','admin/ongkoskirim/form_ongkoskirim',$data);
    }

    public function save(){
        $namaKurir = $this->input->post('namaKurir');
        $namaKotaAsal = $this->input->post('kotaasal');
        $namaKotaTujuan = $this->input->post('kotatujuan');
        $biaya = $this->input->post('biaya');

        $dataInsert = array(
            'idKurir'=>$namaKurir,
            'idKotaAsal'=>$namaKotaAsal,
            'idKotaTujuan'=>$namaKotaTujuan,
            'biaya'=>$biaya
        );
        $this->Mbiaya->insert('tbl_biaya_kirim', $dataInsert);
        redirect('ongkoskirim');
    }

    public function getid($id){
        $data['kurir']=$this->Mbiaya->get_all_data('tbl_kurir')->result();
        $data['kota']=$this->Mbiaya->get_all_data('tbl_kota')->result();
        $dataWhere = array('idBiayaKirim'=>$id);
        $data['ongkir'] = $this->Mbiaya->get_by_id('tbl_biaya_kirim', $dataWhere)->row_object();
        $this->template->load('layout_admin','admin/ongkoskirim/form_ongkoskirim_edit',$data);
    }

    public function edit(){
        $id = $this->input->post('id');
        $namaKurir = $this->input->post('namaKurir');
        $namaKotaAsal = $this->input->post('kotaasal');
        $namaKotaTujuan = $this->input->post('kotatujuan');
        $biaya = $this->input->post('biaya');
        $dataUpdate = array(
            'idKurir'=>$namaKurir,
            'idKotaAsal'=>$namaKotaAsal,
            'idKotaTujuan'=>$namaKotaTujuan,
            'biaya'=>$biaya
        );
        $this->Mbiaya->update('tbl_biaya_kirim', $dataUpdate, 'idBiayaKirim', $id);
        redirect('ongkoskirim');
        }
    
    // public function delete($id){
    //     $dataWhere = array('idBiayaKirim'=>$id);
    //     $this->Mbiaya->delete('tbl_biaya_kirim', $dataWhere, 'idBiayaKirim', $id);
    //     redirect('ongkoskirim');
    // }
    public function delete($id){
        $this->db->where('idBiayaKirim', $id);
        $this->db->delete('tbl_biaya_kirim');
        redirect('ongkoskirim');
    }
}
?>