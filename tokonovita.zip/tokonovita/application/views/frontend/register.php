 <!-- Main Content -->
 <div class="main-content">
     <section class="section">
         <div class="row">
             <div class="col-12 col-sm-10 offset-sm-1 col-md-8 offset-md-2 col-lg-8 offset-lg-2 col-xl-8 offset-xl-2">


                 <div class="card card-primary">
                     <div class="card-header">
                         <h4>Register</h4>
                     </div>

                     <div class="card-body">
                         <?php $this->load->library('form_validation'); ?>
                         <form method="POST" action="<?php echo site_url('home/daftar');?>">
                             <div class="row">
                                 <div class="form-group col-6">
                                     <label for="first_name">Nama Lengkap</label>
                                     <input id="first_name" type="text" class="form-control" name="namaKonsumen"
                                         autofocus value="<?= set_value('namaKonsumen'); ?>
                                         ">
                                     <small class="text-danger"><?= form_error('namaKonsumen'); ?></small>
                                 </div>
                                 <div class="form-group col-6">
                                     <label for="last_name">Email</label>
                                     <input id="last_name" type="email" class="form-control" name="email"
                                         value="<?= set_value('email'); ?>">
                                     <small class="text-danger"><?= form_error('email'); ?></small>
                                 </div>
                             </div>

                             <div class="form-group">
                                 <label for="email">Username</label>
                                 <input id="email" type="text" class="form-control" name="username"
                                     value="<?= set_value('username'); ?>">
                                 <small class="text-danger"><?= form_error('username'); ?></small>
                                 <div class="invalid-feedback">
                                 </div>
                             </div>

                             <div class="row">
                                 <div class="form-group col-6">
                                     <!-- <label for="password" class="d-block">Password</label>
                                     <input id="password" type="password" class="form-control pwstrength"
                                         data-indicator="pwindicator" name="password1">
                                     <small class="text-danger"><?= form_error('password1'); ?>
                                         <div id="pwindicator" class="pwindicator">
                                             <div class="bar"></div>
                                             <div class="label"></div>
                                         </div> -->
                                     <label for="password" class="form-label">Password</label>
                                     <input type="password" class="form-control" id="password" name="password">
                                     <small class="text-danger"><?= form_error('password'); ?></small>
                                 </div>
                                 <div class="form-group col-10">
                                     <!-- <label for="password2" class="d-block">Password Confirmation</label>
                                     <input id="password2" type="password2" class="form-control" name="password2"> -->
                                     <label for="confirmpassword" class="form-label">Confirm Password</label>
                                     <input type="password" class="form-control" id="confirmpassword" name="password2">
                                 </div>
                             </div>

                             <div class="form-divider">
                                 Your Home
                             </div>
                             <div class="row">
                                 <div class="form-group col-12">
                                     <label for="email">Alamat</label>
                                     <input id="email" type="text" class="form-control" name="alamat"
                                         value="<?= set_value('alamat'); ?>">
                                     <small class="text-danger"><?= form_error('alamat'); ?>
                                         <div class="invalid-feedback">
                                         </div>
                                 </div>
                                 <div class="form-group col-9">
                                     <label>Kota</label>
                                     <select class="form-control selectric" name="idKota">
                                         <option>-- Pilih --</option>
                                         <?php foreach($kota as $item) { ?>
                                         <option value="<?= $item->idKota;?>"><?= $item->namaKota; ?></option>
                                         <?php } ?>
                                     </select>
                                 </div>
                                 <div class="form-group col-10">
                                     <label>No Telpon</label>
                                     <input type="text" class="form-control" name="tlpn"
                                         value="<?= set_value('tlpn'); ?>">
                                     <small class="text-danger"><?= form_error('tlpn'); ?>
                                 </div>
                             </div>

                             <div class="form-group">
                                 <button type="submit" class="btn btn-primary btn-lg btn-block">
                                     Register
                                 </button>
                             </div>
                         </form>
                     </div>
                 </div>

             </div>
         </div>
     </section>
 </div>