<div class="main-content">
    <section class="section">

        <div class="section-body">


            <div id="output-status"></div>
            <div class="row">
                <div class="col-md-4">
                    <div class="card">
                        <div class="card-header">
                            <h4>Menu Member</h4>
                        </div>
                        <div class="card-body">
                            <ul class="nav nav-pills flex-column">
                                <li class="nav-item"><a href="http://localhost/tokokita/index.php/member"
                                        class="nav-link">Beranda</a></li>
                                <li class="nav-item"><a href="http://localhost/tokokita/index.php/member/transaksi"
                                        class="nav-link">Transaksi</a></li>
                                <li class="nav-item"><a
                                        href="http://localhost/tokokita/index.php/member/riwayat_transaksi"
                                        class="nav-link">Riwayat Transaksi</a></li>
                                <li class="nav-item"><a href="http://localhost/tokokita/index.php/member/toko"
                                        class="nav-link">Toko</a></li>
                                <li class="nav-item"><a href="http://localhost/tokokita/index.php/member/ubah_profil"
                                        class="nav-link">Ubah Profil</a></li>
                                <li class="nav-item"><a href="http://localhost/tokokita/index.php/member/logout"
                                        class="nav-link">Logout</a></li>
                            </ul>
                        </div>
                    </div>
                </div>

                <div class="col-md-8">
                    <div class="row">
                        <div class="col-12">
                            <div class="card mb-0">
                                <div class="card-body">
                                    <ul class="nav nav-pills">
                                        <li class="nav-item">
                                            <a class="nav-link active"
                                                href="http://localhost/tokonovita/index.php/home/tambahtoko">Silakan
                                                Membuat Toko</a>
                                        </li>

                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div><br>

                    <div class="row">
                        <div class="col-md-12">
                            <div class="card">
                                <div class="card-header">
                                    <h4>Data toko</h4>
                                    <a href="<?php echo site_url('home/tambahtoko');?>" class="btn btn-primary">Tambah
                                        Toko</a>
                                </div>
                                <div class="card-body">
                                    <div class="table-responsive">
                                        <table class="table table-bordered table-md">
                                            <tr>
                                                <th>#</th>
                                                <th>Nama Toko</th>
                                                <th>Deskripsi</th>
                                                <th>Logo</th>
                                                <th>Status</th>
                                                <th>Action</th>
                                            </tr>
                                            <?php if (empty($toko)) { ?>
                                            <tr>
                                                <td colspan="9" class="text-center">Data Kosong</td>
                                            </tr>
                                            <?php } else $no = 0;
                                          foreach($toko as $item) : $no++ ?>
                                            <tr>
                                                <td><?= $no ?></td>
                                                <td><?php echo $item['namaToko']; ?></td>
                                                <td><?php echo $item['deskripsi']; ?></td>
                                                <td><?php echo $item['logo']; ?></td>

                                                <td>
                                                    <?php if ($item['statusAktif'] == 'Y') { ?>
                                                    <span class="badge badge-success badge-ad">Aktif</span>
                                                    <?php } else { ?>
                                                    <span class="badge badge-danger badge-ad">Tidak Aktif</span>
                                                    <?php } ?>
                                                </td>
                                                <td>
                                                    <?php if ($item['statusAktif'] == 'Y') { ?>
                                                    <a href="<?= site_url('home/gantistatustidakaktif/'. $item['idKonsumen']); ?>"
                                                        class="btn btn-info"
                                                        onClick="return confirm('Are you sure for make this change?')">Detail</span>
                                                        <?php } else { ?>
                                                        <a href="<?= site_url('home/gantistatusaktif/'. $item['idKonsumen']); ?>"
                                                            class="btn btn-success"
                                                            onClick="return confirm('Are you sure for make this change?')">Aktif</span>
                                                            <?php } ?>
                                                </td>
                                            </tr>
                                            </td>
                                            </tr>
                                            <?php endforeach; ?>
                                        </table>
                                    </div>
                                </div>
                                </form>
                            </div>
                        </div>
                    </div>


                </div>
            </div>
    </section>
</div>