      <!-- Main Content -->
      <div class="main-content">
          <section class="section">


              <div class="section-body">
                  <h2 class="section-title">Toko</h2>
                  <div class="row">
                      <div class="col-10 col-md-9 col-lg-7">
                          <div class="card">
                              <div class="card-header">
                                  <h4>Data toko</h4>
                                  <a href="<?php echo site_url('member/toko');?>" class="btn btn-primary">Tambah
                                      Toko</a>
                              </div>
                              <div class="card-body">
                                  <div class="table-responsive">
                                      <table class="table table-bordered table-md">
                                          <tr>
                                              <th>#</th>
                                              <th>Nama Toko</th>
                                              <th>Deskripsi</th>
                                              <th>Logo</th>
                                              <th>Status</th>
                                              <th>Action</th>
                                          </tr>
                                          <?php if (empty($toko)) { ?>
                                          <tr>
                                              <td colspan="9" class="text-center">Data Kosong</td>
                                          </tr>
                                          <?php } else $no = 0;
                                          foreach($toko as $item) : $no++ ?>
                                          <tr>
                                              <td><?= $no ?></td>
                                              <td><?php echo $item['namaToko']; ?></td>
                                              <td><?php echo $item['deskripsi']; ?></td>
                                              <td><?php echo $item['logo']; ?></td>

                                              <td>
                                                  <?php if ($item['statusAktif'] == 'Y') { ?>
                                                  <span class="badge badge-success badge-ad">Aktif</span>
                                                  <?php } else { ?>
                                                  <span class="badge badge-danger badge-ad">Tidak Aktif</span>
                                                  <?php } ?>
                                              </td>
                                              <td>
                                                  <?php if ($item['statusAktif'] == 'Y') { ?>
                                                  <a href="<?= site_url('home/gantistatustidakaktif/'. $item['idKonsumen']); ?>"
                                                      class="btn btn-info"
                                                      onClick="return confirm('Are you sure for make this change?')">Detail</span>
                                                      <?php } else { ?>
                                                      <a href="<?= site_url('home/gantistatusaktif/'. $item['idKonsumen']); ?>"
                                                          class="btn btn-success"
                                                          onClick="return confirm('Are you sure for make this change?')">Aktif</span>
                                                          <?php } ?>
                                              </td>
                                          </tr>
                                          </td>
                                          </tr>
                                          <?php endforeach; ?>
                                      </table>
                                  </div>
                              </div>
                              </form>
                          </div>
                      </div>
                  </div>
              </div>
          </section>
      </div>