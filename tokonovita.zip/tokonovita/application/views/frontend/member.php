<div class="main-content">
    <section class="section">

        <div class="section-body">


            <div id="output-status"></div>
            <div class="row">
                <div class="col-md-4">
                    <div class="card">
                        <div class="card-header">
                            <h4>Menu Member</h4>
                        </div>
                        <div class="card-body">
                            <ul class="nav nav-pills flex-column">
                                <li class="nav-item"><a href="http://localhost/tokokita/index.php/member"
                                        class="nav-link">Beranda</a></li>
                                <li class="nav-item"><a href="http://localhost/tokokita/index.php/member/transaksi"
                                        class="nav-link">Transaksi</a></li>
                                <li class="nav-item"><a
                                        href="http://localhost/tokokita/index.php/member/riwayat_transaksi"
                                        class="nav-link">Riwayat Transaksi</a></li>
                                <li class="nav-item"><a href="http://localhost/tokokita/index.php/member/toko"
                                        class="nav-link">Toko</a></li>
                                <li class="nav-item"><a href="http://localhost/tokokita/index.php/member/ubah_profil"
                                        class="nav-link">Ubah Profil</a></li>
                                <li class="nav-item"><a href="<?php echo site_url('home/logout');?>"
                                        class="nav-link">Logout</a></li>
                            </ul>
                        </div>
                    </div>
                </div>